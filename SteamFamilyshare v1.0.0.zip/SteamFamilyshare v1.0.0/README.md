# SteamFamilyshare

SteamFamilyshare ist eine WPF-Anwendung, die Firewall-Regeln für Steam verwaltet und die Benutzerfreundlichkeit beim Teilen von Spielen in Familienkonten verbessert.

## Funktionen

- **Firewall-Regelverwaltung**: Ermöglicht das Aktivieren und Deaktivieren von Firewall-Regeln für Steam.
- **Exe-Pfad-Konfiguration**: Nutzer können den Pfad zu `steam.exe` auswählen und ändern.
- **Statusanzeige**: Zeigt den Status der Firewall-Regel an (aktiv oder deaktiviert).
- **Stylische Benutzeroberfläche**: Die Anwendung bietet eine ansprechende Benutzeroberfläche, die an das Design von Steam angelehnt ist.

## Voraussetzungen

- .NET Framework 4.7.2 oder höher
- Visual Studio Community 2022 (für die Entwicklung)


## Verwendung

- **Exe-Pfad auswählen**: Klicke auf die Schaltfläche "Exe auswählen", um den Pfad zu `steam.exe` zu ändern.
- **Firewall-Regel aktivieren/deaktivieren**: Verwende die entsprechenden Schaltflächen, um die Firewall-Regel zu verwalten.
- **Status prüfen**: Der Status der Regel wird im Statusfeld angezeigt.

## Entwicklungsnotizen

- Die Anwendung integriert die Funktionalitäten der vorherigen `CurrentRuleWindow`-Klasse in das Hauptfenster, um die Benutzeroberfläche zu vereinfachen.
- Die Verwendung vorhandener Methoden wurde bevorzugt, um Redundanz zu vermeiden.
- Das Fenster hat feste Abmessungen (300x400) für eine benutzerfreundliche Oberfläche.

## Beiträge

Beiträge sind willkommen! Bitte erstelle einen Fork des Repositories und sende einen Pull-Request.

## Lizenz

Dieses Projekt ist unter der MIT-Lizenz lizenziert. Siehe die [LICENSE](LICENSE) Datei für weitere Informationen.
