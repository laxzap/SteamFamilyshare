﻿# SteamFamilyshare

This program allows you to play the same game from your friend's library offline simultaneously.

## License

This software is licensed under the MIT License. See the [LICENSE](LICENSE.txt) file for more information.

---

# SteamFamilyshare

Dieses Programm ermöglicht es dir, das gleiche Spiel aus der Bibliothek deines Freundes gleichzeitig offline zu spielen.

## Lizenz

Diese Software wird unter der MIT-Lizenz lizenziert. Siehe die [LICENSE](LICENSE.txt) Datei für weitere Informationen.
